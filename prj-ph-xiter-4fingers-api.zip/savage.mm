#import "Esp/ImGuiDrawView.h"
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#define ICON_FA_COG u8"\uf013"
#define ICON_FA_EXTRA u8"\uf067"
#define ICON_FA_EXCLAMATION_TRIANGLE "\xef\x81\xb1"
#define ICON_FA_INFO_CIRCLE "\xef\x81\x9a"
#define ICON_FA_BARS "\xef\x83\x89"
#define ICON_FA_COMMENT "\xef\x81\xb5"
#include <iostream>
#include <UIKit/UIKit.h>
#include <vector>
#include "iconcpp.h"
#import "pthread.h"
#include <array>
#include <cmath>
#include <deque>
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdint>
#include <cerrno>
#include <cctype>
//#import "API/APIClient.h"
#import "JRMemory.framework/Headers/MemScan.h"
#import "Esp/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_internal.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/zzz.h"
#include "oxorany/oxorany_include.h"
#include "AppLanguage.hpp"
#import "Helper/Mem.h"
#include "font.h"
#import "Esp/Includes.h"
#import "Helper/Vector3.h"
#import "Helper/Vector2.h"
#import "Helper/Quaternion.h"
#import "Helper/Monostring.h"
#import <Foundation/Foundation.h>
#include "Helper/font.h"
#include "Helper/data.h"
#include "ban.cpp"
ImFont* verdana_smol;
ImFont* pixel_big = {};
ImFont* pixel_smol = {};
#include "Helper/Obfuscate.h"
#import "Helper/Hooks.h"
#import "IMGUI/zzz.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>
#include "hook/hook.h"
ImVec4 userColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 espv = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
ImVec4 espi = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 fovColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 nameColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
ImVec4 distanceColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define UIColorFromHex(hexColor) [UIColor colorWithRed:((float)((hexColor & 0xFF0000) >> 16))/255.0 green:((float)((hexColor & 0xFF00) >> 8))/255.0 blue:((float)(hexColor & 0xFF))/255.0 alpha:1.0]
UIWindow *mainWindow;
UIButton *menuView;
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end
bool DrawCustomCheckbox(const char* label, bool* value, ImVec4 fillColor) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;
    ImGuiContext& g = *ImGui::GetCurrentContext();
    const ImGuiStyle& style = g.Style;
    ImGui::PushID(label);
    ImGui::AlignTextToFramePadding();
    float scale = 0.95f; 
    ImGui::SetWindowFontScale(scale);
    ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float square_sz = ImGui::GetFrameHeight() * scale; 
    ImRect check_bb(pos, ImVec2(pos.x + square_sz, pos.y + square_sz));
    ImRect total_bb(
        pos,
        ImVec2(
            pos.x + square_sz + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f),
            pos.y + label_size.y + style.FramePadding.y * scale * 2.0f
        )
    );
    ImGui::ItemSize(total_bb, style.FramePadding.y * scale);
    if (!ImGui::ItemAdd(total_bb, ImGui::GetID("##checkbox"))) {
        ImGui::PopID();
        ImGui::SetWindowFontScale(1.0f); 
        return false;
    }
    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(check_bb, ImGui::GetID("##checkbox"), &hovered, &held);
    if (pressed)
        *value = !(*value);
    ImU32 box_col = ImGui::GetColorU32(ImGuiCol_FrameBg);
    if (hovered || held)
        box_col = ImGui::GetColorU32(ImGuiCol_FrameBgHovered);
    if (*value) {
        box_col = ImGui::ColorConvertFloat4ToU32(fillColor); 
    } else {
        box_col = ImGui::ColorConvertFloat4ToU32(ImVec4(0.15f, 0.15f, 0.15f, 1.0f)); 
    }
    ImGui::RenderNavHighlight(total_bb, ImGui::GetID("##checkbox"));
    ImGui::RenderFrame(check_bb.Min, check_bb.Max, box_col, true, style.FrameRounding);
    if (label_size.x > 0.0f) {
        ImVec2 text_pos(check_bb.Max.x + style.ItemInnerSpacing.x, check_bb.Min.y + style.FramePadding.y * scale);
        ImGui::RenderText(text_pos, label);
    }
    ImGui::PopID();
    ImGui::SetWindowFontScale(1.0f); 
    return pressed;
}
ImVec2 menuPos;
ImVec2 menuSize;
extern float SpinBotSpeed;
@implementation ImGuiDrawView
ImFont *_espFont;
ImFont* verdanab;
ImFont* icons;
ImFont* interb;
ImFont* Urbanist;
static bool MenDeal = true;
ImVec4 menuColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); 
BOOL hasGhostBeenDrawn = NO;
static bool StreamerMode = true;
bool Guest = false;
bool fakeLagEnabled = false;
bool FastReloadEnabled = true;
bool Telekill = false;
bool SpeeeX2Enabled = false;
bool NoRecoilEnabled = false;
bool SpinBot390 = false;
bool WallGlowEnabled = false;
bool WallFlyEnabled = false;
bool WallHackEnabled = false;
bool ScopeEnabled = false;
bool BypassEnabled = true;
bool ShowFOV = false;
bool antiban(void *instance) {
    return false;
}
bool teste(void* _this){
    if (Guest){
        return true;
    } else { 
        return false; 
    }
}

- (void)toggleSpeedX2:(BOOL)enable {
    static bool wasScanned = false;
    static vector<void*> results;
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x200000000};
    if (enable) {
        if (!wasScanned) {
            uint64_t search = 4397530849764387586;
            engine->JRScanMemory(range, &search, JR_Search_Type_ULong);
            results = engine->getAllResults();
            wasScanned = true;
        }
        uint64_t modify = 4366458311853765201;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
    } else {
        uint64_t modify = 4397530849764387586;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
        wasScanned = false;
        results.clear();
    }
    delete engine;
}
- (void)toggleNoRecoil:(BOOL)enable {
    static bool wasScanned = false;
    static vector<void*> results;
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    if (enable) {
        if (!wasScanned) {
            uint32_t search = 1016018816;
            engine->JRScanMemory(range, &search, JR_Search_Type_UInt);
            results = engine->getAllResults();
            wasScanned = true;
        }
        uint32_t modify = 180;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
        }
    } else {
        uint32_t modify = 1016018816;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
        }
        wasScanned = false;
        results.clear();
    }
    delete engine;
}
- (void)toggleWallGlow:(BOOL)enable {
    static bool wasScanned = false;
    static vector<void*> results;
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    if (enable) {
        if (!wasScanned) {
            float search = 1.22f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
            wasScanned = true;
        }
        float modify = 965.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 1.22f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        wasScanned = false;
        results.clear();
    }
    delete engine;
}
- (void)toggleWallFly:(BOOL)enable {
    static bool wasScanned = false;
    static vector<void*> results;
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    if (enable) {
        if (!wasScanned) {
            float search = 1.5f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
            wasScanned = true;
        }
        float modify = 900.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 1.5f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        wasScanned = false;
        results.clear();
    }
    delete engine;
}
- (void)toggleWallHack:(BOOL)enable {
    static bool wasScanned = false;
    static vector<void*> results;
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    if (enable) {
        if (!wasScanned) {
            float search = 2;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            float search1 = 0.10000000149;
            engine->JRNearBySearch(0x20, &search1, JR_Search_Type_Float);
            float search2 = 3;
            engine->JRScanMemory(range, &search2, JR_Search_Type_Float);
            float search3 = 4.2038954e-45;
            engine->JRScanMemory(range, &search3, JR_Search_Type_Float);
            float search4 = 4.2038954e-45;
            engine->JRNearBySearch(0x20, &search4, JR_Search_Type_Float);
            results = engine->getAllResults();
            wasScanned = true;
        }
        float modify = -99;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        wasScanned = false;
        results.clear();
    }
    delete engine;
}
- (void)toggleScope:(BOOL)enable {
    static bool wasScanned = false;
    static vector<void*> results;
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    if (enable) {
        if (!wasScanned) {
            float search = 0.03f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
            wasScanned = true;
        }
        float modify = 10.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 0.03f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        wasScanned = false;
        results.clear();
    }
    delete engine;
}
- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];
    if (!self.device) abort();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGuiStyle& style = ImGui::GetStyle();
style.Colors[ImGuiCol_Text]         = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
ImVec4 brightRed       = ImVec4(1.00f, 0.00f, 0.00f, 1.00f);
ImVec4 brightRedHover  = ImVec4(0.90f, 0.10f, 0.10f, 1.00f);
ImVec4 brightRedActive = ImVec4(0.75f, 0.00f, 0.00f, 1.00f);
ImVec4 darkBackground     = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
ImVec4 mediumGray         = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
ImVec4 mediumGrayHover    = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
ImVec4 mediumGrayActive   = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
style.Colors[ImGuiCol_WindowBg]               = darkBackground;
style.Colors[ImGuiCol_ChildBg]                = darkBackground;
style.Colors[ImGuiCol_PopupBg]                = darkBackground;
style.Colors[ImGuiCol_TitleBg]                = brightRed;
style.Colors[ImGuiCol_TitleBgActive]          = brightRedHover;
style.Colors[ImGuiCol_TitleBgCollapsed]       = brightRed;
style.Colors[ImGuiCol_Button]                 = brightRed;
style.Colors[ImGuiCol_ButtonHovered]          = brightRedHover;
style.Colors[ImGuiCol_ButtonActive]           = brightRedActive;
style.Colors[ImGuiCol_FrameBg]                = ImVec4(0.20f, 0.20f, 0.20f, 0.60f);
style.Colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.30f, 0.30f, 0.30f, 0.80f);
style.Colors[ImGuiCol_FrameBgActive]          = ImVec4(0.35f, 0.35f, 0.35f, 0.90f);
style.Colors[ImGuiCol_Header]                 = mediumGray;
style.Colors[ImGuiCol_HeaderHovered]          = mediumGrayHover;
style.Colors[ImGuiCol_HeaderActive]           = mediumGrayActive;
style.Colors[ImGuiCol_Tab]                    = brightRed;
style.Colors[ImGuiCol_TabHovered]             = brightRedHover;
style.Colors[ImGuiCol_TabActive]              = brightRedActive;
style.Colors[ImGuiCol_ScrollbarBg]            = darkBackground;
style.Colors[ImGuiCol_ScrollbarGrab]          = brightRedHover;
style.Colors[ImGuiCol_ScrollbarGrabHovered]   = brightRedActive;
style.Colors[ImGuiCol_ScrollbarGrabActive]    = brightRedActive;
style.Colors[ImGuiCol_CheckMark]              = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
style.Colors[ImGuiCol_SliderGrab]             = brightRedHover;
style.Colors[ImGuiCol_SliderGrabActive]       = brightRedActive;
style.FrameRounding = 10.0f;
style.FrameRounding = 10.0f;
style.WindowRounding = 5.0f;
style.ChildRounding = 5.0f;
style.FrameRounding = 5.0f;
style.GrabRounding = 5.0f;
style.PopupRounding = 5.0f;
style.ScrollbarRounding = 5.0f;
style.TabRounding = 5.0f;
style.WindowBorderSize = 1.0f;
style.FrameBorderSize = 1.0f;
style.PopupBorderSize = 1.0f;
style.WindowPadding = ImVec2(10.0f, 8.0f);
style.FramePadding = ImVec2(6.0f, 4.0f);
style.ItemSpacing = ImVec2(6.0f, 2.0f);
static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
ImFontConfig icons_config;
ImFontConfig CustomFont;
CustomFont.FontDataOwnedByAtlas = false;
icons_config.MergeMode = true;
icons_config.PixelSnapH = true;
io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 21.f, &CustomFont);
io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);
io.Fonts->AddFontDefault();
ImFont* font = io.Fonts->AddFontFromMemoryTTF(sansbold, sizeof(sansbold), 21.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
(void)font;
verdana_smol = io.Fonts->AddFontFromMemoryTTF(verdana, sizeof verdana, 40, NULL, io.Fonts->GetGlyphRangesCyrillic());
pixel_big = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 400, NULL, io.Fonts->GetGlyphRangesCyrillic());
pixel_smol = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 10*2, NULL, io.Fonts->GetGlyphRangesCyrillic());
ImGui_ImplMetal_Init(_device);
game_sdk->init();
return self;
}
+ (void)showChange:(BOOL)open {
MenDeal = open;
}
+ (BOOL)isMenuShowing {
return MenDeal;
}
- (MTKView *)mtkView {
return (MTKView *)self.view;
}
- (void)loadView
{
CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}
- (void)viewDidLoad {
[super viewDidLoad];
self.mtkView.device = self.device;
self.mtkView.delegate = self;
self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
self.mtkView.clipsToBounds = YES;
self.mtkView.clipsToBounds = YES;
}
#pragma mark - Interaction
- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}
#pragma mark - MTKViewDelegate
- (void)drawInMTKView:(MTKView*)view
{
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    hideRecordTextfield.secureTextEntry = StreamerMode;
    if (MenDeal == true) 
    {
        [self.view setUserInteractionEnabled:YES];
        [self.view.superview setUserInteractionEnabled:YES];
        [menuTouchView setUserInteractionEnabled:YES];
    } 
    else if (MenDeal == false) 
    {
        [self.view setUserInteractionEnabled:NO];
        [self.view.superview setUserInteractionEnabled:NO];
        [menuTouchView setUserInteractionEnabled:NO];
    }
MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
if (renderPassDescriptor != nil) 
{
    id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
    [renderEncoder pushDebugGroup:@"ImGui Jane"];
    ImGui_ImplMetal_NewFrame(renderPassDescriptor);
    ImGui::NewFrame();
    ImGuiStyle& style = ImGui::GetStyle();
    ImFont* font = ImGui::GetFont();
    font->Scale = 16.f / font->FontSize;
    style.WindowRounding = 12.0f; 
    CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 340) / 2;
    CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 250) / 2;
ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(340, 250), ImGuiCond_FirstUseEver);
if (MenDeal == true)
{
    static int selected_tab = 0;
    ImGui::SetNextWindowSize(ImVec2(380, 260), ImGuiCond_Always);
    ImGui::Begin(LocalizedString("                              FFH4X @PH XITER").c_str(), &MenDeal, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    static bool styleInitialized = false;
    if (!styleInitialized) {
        ImGuiStyle& style = ImGui::GetStyle();
        style.Colors[ImGuiCol_WindowBg]         = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
        style.Colors[ImGuiCol_TitleBg]          = menuColor;
        style.Colors[ImGuiCol_TitleBgActive]    = ImVec4(menuColor.x * 1.1f, menuColor.y * 1.1f, menuColor.z * 1.1f, 1.0f);
        style.Colors[ImGuiCol_TitleBgCollapsed] = menuColor;
        style.Colors[ImGuiCol_Tab]              = menuColor;
        style.Colors[ImGuiCol_TabHovered]       = ImVec4(menuColor.x * 1.1f, menuColor.y * 1.1f, menuColor.z * 1.1f, 1.0f);
        style.Colors[ImGuiCol_TabActive]        = ImVec4(menuColor.x * 1.2f, menuColor.y * 1.2f, menuColor.z * 1.2f, 1.0f);
        style.Colors[ImGuiCol_Text]             = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
        style.Colors[ImGuiCol_SliderGrab]       = menuColor;
        style.Colors[ImGuiCol_SliderGrabActive] = menuColor;
        style.Colors[ImGuiCol_Button]           = menuColor;
        style.Colors[ImGuiCol_ButtonHovered]    = ImVec4(menuColor.x * 1.1f, menuColor.y * 1.1f, menuColor.z * 1.1f, 1.0f);
        style.Colors[ImGuiCol_ButtonActive]     = ImVec4(menuColor.x * 1.2f, menuColor.y * 1.2f, menuColor.z * 1.2f, 1.0f);
        style.Colors[ImGuiCol_Separator]        = menuColor;
        style.Colors[ImGuiCol_CheckMark]        = menuColor;
        style.Colors[ImGuiCol_Header]           = menuColor;
        style.Colors[ImGuiCol_HeaderHovered]    = ImVec4(menuColor.x * 1.1f, menuColor.y * 1.1f, menuColor.z * 1.1f, 1.0f);
        style.Colors[ImGuiCol_HeaderActive]     = ImVec4(menuColor.x * 1.2f, menuColor.y * 1.2f, menuColor.z * 1.2f, 1.0f);
        style.Colors[ImGuiCol_FrameBg]          = ImVec4(0.1f, 0.1f, 0.1f, 1.0f);
        styleInitialized = true;
    }
    ImGui::Columns(2, "MainColumns", false);
ImGui::SetColumnWidth(0, 60.0f); 
ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 2);
ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 3));
ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 6));
ImVec2 buttonSize = ImVec2(51.0f, 51.0f);
if (ImGui::Button(ICON_FA_CROSSHAIRS "", buttonSize)) { selected_tab = 0; }
if (ImGui::Button(ICON_FA_EYE "", buttonSize)) { selected_tab = 1; }
if (ImGui::Button(ICON_FA_COG "", buttonSize)) { selected_tab = 2; }
if (ImGui::Button(ICON_FA_ADDRESS_CARD "", buttonSize)) { selected_tab = 3; }
ImGui::PopStyleVar(2); 
ImGui::NextColumn();
ImGui::SetCursorPosX(ImGui::GetCursorPosX() - 15);
ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 5));
ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 5));
if (selected_tab == 0) {
    float comprimento = 300.0f; 
    float espessura = 1.0f;
    ImU32 cor = ImGui::GetColorU32(ImGuiCol_Separator); 
    float deslocamentoX = 15.0f; 
    ImVec2 pos = ImGui::GetCursorScreenPos();
    pos.x += deslocamentoX; 
    pos.y += 3.0f;           
    ImDrawList* draw = ImGui::GetWindowDrawList();
    draw->AddLine(pos, ImVec2(pos.x + comprimento, pos.y), cor, espessura);
    ImGui::Dummy(ImVec2(comprimento + deslocamentoX, espessura + 4));
    DrawCustomCheckbox(LocalizedString("Ativar Aimbot").c_str(), &Vars.Aimbot, menuColor);
    ImGui::SameLine(145.0f);
    DrawCustomCheckbox(LocalizedString("Ignorar Derrubados").c_str(), &Vars.IgnoreKnocked, menuColor);
    DrawCustomCheckbox(LocalizedString("Exibir FOV").c_str(), &Vars.isAimFov, menuColor);
    ImGui::SameLine(145.0f);
    DrawCustomCheckbox(LocalizedString("Apenas Visíveis").c_str(), &Vars.VisibleCheck, menuColor);
    ImGui::PushItemWidth(185.0f); 
    ImGui::SliderFloat(LocalizedString("Regular Fov").c_str(), &Vars.AimFov, 0.f, 360.f, "%.1f");
    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.25f, 0.25f, 0.25f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,  ImVec4(0.35f, 0.35f, 0.35f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::Combo(LocalizedString("Puxada").c_str(), &Vars.AimHitbox, Vars.aimHitboxes, 3);
    ImGui::PopStyleColor(4);
    ImGui::Text("%s", LocalizedString("Tipo de Aimbot:").c_str());
    ImGui::RadioButton(LocalizedString("Ao Atirar").c_str(), &Vars.AimWhen, 3);
    ImGui::SameLine();
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 10);
    ImGui::RadioButton(LocalizedString("Ao Olhar").c_str(), &Vars.AimWhen, 0);
    ImGui::PopItemWidth();
} else if (selected_tab == 1) {
float comprimento = 300.0f; 
float espessura = 1.0f;
ImU32 cor = ImGui::GetColorU32(ImGuiCol_Separator); 
float deslocamentoX = 15.0f; 
ImVec2 pos = ImGui::GetCursorScreenPos();
pos.x += deslocamentoX; 
pos.y += 3.0f;           
ImDrawList* draw = ImGui::GetWindowDrawList();
draw->AddLine(pos, ImVec2(pos.x + comprimento, pos.y), cor, espessura);
ImGui::Dummy(ImVec2(comprimento + deslocamentoX, espessura + 4));
    ImGui::Columns(2, "ESPColumns", false);
DrawCustomCheckbox(LocalizedString("Ativar ESP").c_str(), &Vars.Enable, menuColor);
float firstCheckboxWidth = ImGui::GetItemRectSize().x;
ImGui::SameLine(firstCheckboxWidth + 20.0f);
DrawCustomCheckbox(LocalizedString("Esconder Painel").c_str(), &StreamerMode, menuColor);
DrawCustomCheckbox(LocalizedString("ESP Linha").c_str(), &Vars.lines, menuColor);
if (Vars.lines) {
    ImGui::SameLine(0.0f, 10.0f);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
    ImGui::Text("%s", LocalizedString("Estilo:").c_str());
    ImGui::PopStyleColor();
    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.25f, 0.25f, 0.25f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,  ImVec4(0.35f, 0.35f, 0.35f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::SameLine(0.0f, 5.0f);
    static const char* lineStyles[] = { " Cima", " Baixo" };
    ImGui::SetNextItemWidth(100);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    ImGui::Combo(ENCRYPT("##LineStyle"), &Vars.LineStyle, lineStyles, IM_ARRAYSIZE(lineStyles));
    ImGui::PopStyleColor(4);
}
DrawCustomCheckbox(LocalizedString("ESP Caixa").c_str(), &Vars.Box, menuColor);
if (Vars.Box) {
    ImGui::SameLine(0.0f, 10.0f);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
    ImGui::Text("%s", LocalizedString("Estilo:").c_str());
    ImGui::PopStyleColor();
    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.25f, 0.25f, 0.25f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,  ImVec4(0.35f, 0.35f, 0.35f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::SameLine(0.0f, 5.0f);
    static const char* boxStyles[] = { " Redondo", " Cornered" };
    ImGui::SetNextItemWidth(100);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    ImGui::Combo(ENCRYPT("##BoxStyle"), &Vars.BoxStyle, boxStyles, IM_ARRAYSIZE(boxStyles));
    ImGui::PopStyleColor(4);
}
DrawCustomCheckbox(LocalizedString("ESP Nome").c_str(), &Vars.Name, menuColor);
if (Vars.Name) {
    ImGui::SameLine(0.0f, 10.0f);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    ImGui::Text("%s", LocalizedString("Estilo:").c_str());
    ImGui::PopStyleColor();
    ImGui::SameLine(0.0f, 5.0f);
    static const char* nameStyles[] = { " Com Sombra", " Sem Sombra" };
    ImGui::SetNextItemWidth(120);
    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.25f, 0.25f, 0.25f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,  ImVec4(0.35f, 0.35f, 0.35f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    if (ImGui::BeginCombo(ENCRYPT("##NameStyle"), nameStyles[Vars.NameStyle])) {
        for (int i = 0; i < IM_ARRAYSIZE(nameStyles); i++) {
            bool is_selected = (Vars.NameStyle == i);
            if (ImGui::Selectable(nameStyles[i], is_selected)) {
                Vars.NameStyle = i;
            }
            if (is_selected)
                ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    ImGui::PopStyleColor(4);
}
DrawCustomCheckbox(LocalizedString("ESP Vida").c_str(), &Vars.Health, menuColor);
if (Vars.Health) {
    ImGui::SameLine(0.0f, 10.0f);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    ImGui::Text("%s", LocalizedString("Posição:").c_str());
    ImGui::PopStyleColor();
    ImGui::SameLine(0.0f, 5.0f);
    static const char* healthPositions[] = { " Esquerda", " Direita" };
    ImGui::SetNextItemWidth(100);
    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.25f, 0.25f, 0.25f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,  ImVec4(0.35f, 0.35f, 0.35f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,        ImVec4(0.15f, 0.15f, 0.15f, 1.0f));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
    if (ImGui::BeginCombo(ENCRYPT("##HealthPosition"), healthPositions[Vars.HealthPosition])) {
        for (int i = 0; i < IM_ARRAYSIZE(healthPositions); i++) {
            bool is_selected = (Vars.HealthPosition == i);
            if (ImGui::Selectable(healthPositions[i], is_selected)) {
                Vars.HealthPosition = i;
            }
            if (is_selected)
                ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    ImGui::PopStyleColor(4);
}
DrawCustomCheckbox(LocalizedString("ESP Esqueleto").c_str(), &Vars.skeleton, menuColor);
ImGui::Columns(1);
} else if (selected_tab == 2) {

    // ── Hacks ─────────────────────────────────────────────
    {
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 15);
        float colW = ImGui::GetContentRegionAvail().x * 0.5f;
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.0f, 2.0f));

        DrawCustomCheckbox(LocalizedString("Teleport 8m").c_str(), &Vars.tele10,      menuColor);
        ImGui::SameLine(colW);
        DrawCustomCheckbox(LocalizedString("Voar Player").c_str(), &Vars.UpPlayerOne, menuColor);

        DrawCustomCheckbox(LocalizedString("Guest").c_str(), &Guest, menuColor);
        ImGui::SameLine(colW);
        if (DrawCustomCheckbox(LocalizedString("Speed").c_str(), &SpeeeX2Enabled, menuColor))
            [self toggleSpeedX2:SpeeeX2Enabled];

        DrawCustomCheckbox(LocalizedString("No Recoil OFF").c_str(), &NoRecoilEnabled, menuColor);
        ImGui::SameLine(colW);
        DrawCustomCheckbox(LocalizedString("Spin Bot").c_str(), &SpinBot390, menuColor);

        if (SpinBot390) {
            ImGui::Text("%s", LocalizedString("Velocidade Spin").c_str());
            ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x);
            ImGui::SliderFloat(ENCRYPT("##SpinSpeed"), &SpinBotSpeed, 1.0f, 5.0f, "%.1f");
            ImGui::PopItemWidth();
        }

        ImGui::PopStyleVar();
    }

    // ── Personalização ────────────────────────────────────
    ImGui::Dummy(ImVec2(0, 1));
    ImGui::Text(ICON_FA_BARS "  %s", LocalizedString("Personalização").c_str());

    ImGuiStyle& style3 = ImGui::GetStyle();

    // Cor do Menu
    {
        ImGui::BeginGroup();
        if (ImGui::ColorButton(ENCRYPT("##CorMenu"), menuColor, ImGuiColorEditFlags_NoTooltip, ImVec2(22, 22)))
            ImGui::OpenPopup(ENCRYPT("PickerCorMenu"));
        ImGui::SameLine(0, 8); ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 2);
        ImGui::Text("%s", LocalizedString("Cor do Menu").c_str());
        ImGui::EndGroup();
        if (ImGui::BeginPopup(ENCRYPT("PickerCorMenu"))) {
            ImGuiColorEditFlags f = ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoAlpha |
                                    ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview;
            if (ImGui::ColorPicker3(ENCRYPT("##picker"), (float*)&menuColor, f)) {
                auto mc  = menuColor;
                auto mc1 = ImVec4(mc.x*1.1f, mc.y*1.1f, mc.z*1.1f, 1.0f);
                auto mc2 = ImVec4(mc.x*1.2f, mc.y*1.2f, mc.z*1.2f, 1.0f);
                style3.Colors[ImGuiCol_TitleBg]         = mc;
                style3.Colors[ImGuiCol_TitleBgActive]   = mc1;
                style3.Colors[ImGuiCol_TitleBgCollapsed]= mc;
                style3.Colors[ImGuiCol_Tab]             = mc;
                style3.Colors[ImGuiCol_TabHovered]      = mc1;
                style3.Colors[ImGuiCol_TabActive]       = mc2;
                style3.Colors[ImGuiCol_SliderGrab]      = mc;
                style3.Colors[ImGuiCol_SliderGrabActive]= mc;
                style3.Colors[ImGuiCol_Button]          = mc;
                style3.Colors[ImGuiCol_ButtonHovered]   = mc1;
                style3.Colors[ImGuiCol_ButtonActive]    = mc2;
                style3.Colors[ImGuiCol_Separator]       = mc;
                style3.Colors[ImGuiCol_CheckMark]       = mc;
                style3.Colors[ImGuiCol_Header]          = mc;
                style3.Colors[ImGuiCol_HeaderHovered]   = mc1;
                style3.Colors[ImGuiCol_HeaderActive]    = mc2;
                style3.Colors[ImGuiCol_FrameBg]         = ImVec4(0.1f,0.1f,0.1f,1.0f);
            }
            ImGui::EndPopup();
        }
    }

    // Cor ESP Visível
    {
        ImGui::BeginGroup();
        if (ImGui::ColorButton(ENCRYPT("##ESPVis"), colorESPVisible, ImGuiColorEditFlags_NoTooltip, ImVec2(22, 22)))
            ImGui::OpenPopup(ENCRYPT("PickerESPVis"));
        ImGui::SameLine(0, 8); ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 2);
        ImGui::Text("%s", LocalizedString("Cor da ESP Visível").c_str());
        ImGui::EndGroup();
        if (ImGui::BeginPopup(ENCRYPT("PickerESPVis"))) {
            ImGuiColorEditFlags f = ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoAlpha |
                                    ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview;
            ImGui::ColorPicker3(ENCRYPT("##pVis"), (float*)&colorESPVisible, f);
            ImGui::EndPopup();
        }
    }

    // Cor ESP Invisível
    {
        ImGui::BeginGroup();
        if (ImGui::ColorButton(ENCRYPT("##ESPInv"), colorESPInvisible, ImGuiColorEditFlags_NoTooltip, ImVec2(22, 22)))
            ImGui::OpenPopup(ENCRYPT("PickerESPInv"));
        ImGui::SameLine(0, 8); ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 2);
        ImGui::Text("%s", LocalizedString("Cor da ESP Invisível").c_str());
        ImGui::EndGroup();
        if (ImGui::BeginPopup(ENCRYPT("PickerESPInv"))) {
            ImGuiColorEditFlags f = ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoAlpha |
                                    ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview;
            ImGui::ColorPicker3(ENCRYPT("##pInv"), (float*)&colorESPInvisible, f);
            ImGui::EndPopup();
        }
    }

    // Slider Transparência
    static float menuAlpha = 1.0f;
    ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x - 90.0f);
    if (ImGui::SliderFloat(LocalizedString("Transparência").c_str(), &menuAlpha, 0.1f, 1.0f, "%.2f"))
        ImGui::GetStyle().Alpha = menuAlpha;
    ImGui::PopItemWidth();

} else if (selected_tab == 3) {

    // ── Info table ────────────────────────────────────────
    ImGui::Dummy(ImVec2(0, 2));

    float labelW = 120.0f;

    // Status
    ImGui::Text("%s", LocalizedString("Status").c_str());
    ImGui::SameLine(labelW);
    ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.2f, 1.0f), "%s", LocalizedString("Online").c_str());

    // FPS
    ImGui::Text("FPS");
    ImGui::SameLine(labelW);
    ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.2f, 1.0f), "%.0f", ImGui::GetIO().Framerate);

    // Desenvolvedor
    ImGui::Text("%s", LocalizedString("Desenvolvedor").c_str());
    ImGui::SameLine(labelW);
    ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.2f, 1.0f), "Easy cheats");

    // ── Botões Fix Login e Discord lado a lado ────────────
    ImGui::Dummy(ImVec2(0, 6));

    float totalW  = ImGui::GetContentRegionAvail().x;
    float btnW    = (totalW - 8.0f) / 2.0f;  // 8px de espaço entre eles

    // Fix Login — cor do menu
    ImGui::PushStyleColor(ImGuiCol_Button,        menuColor);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(menuColor.x*1.1f, menuColor.y*1.1f, menuColor.z*1.1f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(menuColor.x*0.8f, menuColor.y*0.8f, menuColor.z*0.8f, 1.0f));
    if (ImGui::Button(LocalizedString("Fix Login").c_str(), ImVec2(btnW, 28))) {
        // ação fix login
    }
    ImGui::PopStyleColor(3);

    ImGui::SameLine(0, 8);

    // Discord — azul
    ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.34f, 0.49f, 0.93f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.44f, 0.59f, 1.00f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.24f, 0.39f, 0.83f, 1.0f));
    if (ImGui::Button(LocalizedString("Discord").c_str(), ImVec2(btnW, 28))) {
        [[UIApplication sharedApplication]
            openURL:[NSURL URLWithString:@"https://discord.gg/dGVm9uwVJb"]
            options:@{}
            completionHandler:nil];
    }
    ImGui::PopStyleColor(3);

}
            ImGui::PopStyleVar(2);
            ImGui::Columns(1); 
            menuPos = ImGui::GetWindowPos();
            menuSize = ImGui::GetWindowSize();
            ImGui::End();
        }
        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
        (void)draw_list;
        get_players();
        aimbot();
        NoRecoilHook();
if (Vars.isAimFov && Vars.AimFov > 0) {
    ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2);
    if (Vars.fovaimglow) {
        static float rainbowHue = 0.0f;
        rainbowHue += ImGui::GetIO().DeltaTime * 0.8f;
        if (rainbowHue > 1.0f) rainbowHue = 0.0f;
        drawcircleglow(
            draw_list,
            center,
            Vars.AimFov,
            ImColor::HSV(rainbowHue, 0.8f, 1.0f),
            100,
            2.0f,
            12
        );
    } else {
        draw_list->AddCircle(
            center,
            Vars.AimFov,
            ImColor(255, 255, 255, 150),
            100,
            1.8f
        );
    }
}
        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];
        [commandBuffer presentDrawable:view.currentDrawable];
        [commandBuffer commit];
    } 
} 

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {}

@end

static void Transform_INTERNAL_SetRotation(void *transform, Quaternion quat) {
    if (!transform) return;
    void (*_Transform_INTERNAL_SetRotation)(void *transform, Quaternion in) = (void (*)(void *, Quaternion))getRealOffset(oxo("0x929BBD0"));
    _Transform_INTERNAL_SetRotation(transform, quat);
}

float currentY = 0.0f;
float SpinBotSpeed = 5.0f;

void* RotatePlayer360(void* arg) {
    while (true) {
        if (SpinBot390) {
            void* match = game_sdk->Curent_Match();
            if (match) {
                void* localPlayer = game_sdk->GetLocalPlayer(match);
                if (localPlayer) {
                    void* transform = game_sdk->Component_GetTransform(localPlayer);
                    if (transform) {
                        currentY += SpinBotSpeed;
                        if (currentY >= 360.0f) currentY = 0;

                        float rad = currentY * (M_PI / 180.0f);
                        Quaternion rot;
                        rot.x = 0;
                        rot.y = sinf(rad / 2);
                        rot.z = 0;
                        rot.w = cosf(rad / 2);

                        Transform_INTERNAL_SetRotation(transform, rot);
                    }
                }
            }
        }
        usleep(1000);
    }
    return NULL;
}

void hooking() {
void* address[] = {
               (void*)getRealOffset(ENCRYPTOFFSET("0x1030FA8BC")),
               (void*)getRealOffset(ENCRYPTOFFSET("0x4E4657C")),
    };
    void* function[] = {
                (void*)antiban,
                (void*)teste,
    };
            hook(address, function, 2);
}
void *hack_thread(void *) {
    sleep(5);
    hooking();
    pthread_exit(nullptr);
    return nullptr;
}

void __attribute__((constructor)) initialize() {
    pthread_t hacks;
    pthread_create(&hacks, NULL, hack_thread, NULL);

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pthread_t spinThread;
        pthread_create(&spinThread, NULL, RotatePlayer360, NULL);
        pthread_detach(spinThread);
    });
}
