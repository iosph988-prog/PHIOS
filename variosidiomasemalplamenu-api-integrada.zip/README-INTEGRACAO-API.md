# Integração da API de licença no projeto Theos

Este pacote integra um gate de licença ao alvo Theos `PHBOLSONARO`. O menu e a thread principal de hacks só são iniciados depois de uma validação HTTPS bem-sucedida.

## Fluxo

A tela de licença aparece antes do menu. A key é enviada por `POST` para:

`https://apikeydash-rhz9ayn4.manus.space/api/license/validate`

O payload contém `key`, `device_id`, `package` e `app_version`. O acesso só é liberado quando a resposta HTTP é 200 e o campo JSON `valid` é exatamente o booleano `true`. Strings como `"true"` não são aceitas.

A key aprovada é armazenada no Keychain como dado local do dispositivo. O servidor inicia o prazo de 1 a 30 dias na primeira validação da key; gerar a key no painel não inicia a contagem.

## Arquivos adicionados ou alterados

| Arquivo | Função |
| --- | --- |
| `Sile/LicenseGate.h` | Interface do gate de licença |
| `Sile/LicenseGate.mm` | Keychain, tela de entrada, POST HTTPS e validação estrita |
| `Sile/Esp/LoadView.mm` | Chama o gate antes de criar o menu e iniciar `hack_thread` |
| `Sile/Makefile` | Inclui `LicenseGate.mm` no alvo Theos |
| `Sile/.github/workflows/build.yml` | Instala Theos, compila e publica o `.deb` como artefato |

## Compilação pelo GitHub

Envie o conteúdo do pacote para um repositório e abra a aba **Actions**. Execute manualmente o workflow **Build Theos tweak**. O resultado estará disponível em **Artifacts** com o nome `PHBOLSONARO-rootless-package`.

O workflow não contém senha, certificado ou chave privada. Caso a instalação final exija assinatura ou credenciais de distribuição, esses valores devem ser cadastrados como GitHub Secrets e usados somente em um passo separado de assinatura.

## Dados do alvo

- Tweak: `PHBOLSONARO`
- Pacote: `com.lostx.wq.jitmenu`
- Versão do tweak: `9.111.X`
- Arquitetura: `arm64`
- Esquema: rootless

Não inclua senhas, certificados `.p12`, chaves privadas ou tokens nos commits. O endpoint público serve apenas para validação; operações administrativas continuam protegidas no painel.
