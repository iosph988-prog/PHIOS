import SwiftUI
import UIKit

private extension Notification.Name {
    static let phxiterPatchDiagnostic = Notification.Name("PHXITER.patchDiagnostic")
}

struct PatchProjectsView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var store: PatchProjectStore
    @State private var searchText = ""
    @State private var currentStatus = "Original restaurado"
    @State private var diagnosticLogs: [String] = [
        "[--:--:--] Sistema pronto",
        "[--:--:--] Nenhum mod ativo"
    ]
    private let showsFreeFireCard: Bool
    private let allowedPackageNames: Set<String>?
    private let allowedBundleIdentifier: String?

    private static let freeFirePackageNames: Set<String> = [
        "Hologramaverde.PHPRJ", "Hologramarosa.PHPRJ", "Hsalto+antena.PHPRJ", "Magiccache.PHPRJ",
        "Hspeitoavatar.PHPRJ", "Hspeito100%cache.PHPRJ", "Hsaltocache.PHPRJ", "Hologramavermelho.PHPRJ",
        "120FPS.PHPRJ", "Hspescoçocache.PHPRJ"
    ]

    private static let freeFireMaxPackageNames: Set<String> = [
        "Pescoço+antenaavatar.PHPRJ", "Hologramazul.PHPRJ", "Magicavatar.PHPRJ", "Hspeito+antenaavatar.PHPRJ", "Hologramaverde_MAX.PHPRJ"
    ]

    init(
        showsFreeFireCard: Bool = true,
        allowedPackageNames: Set<String>? = nil,
        allowedBundleIdentifier: String? = nil,
        store: PatchProjectStore? = nil
    ) {
        _store = ObservedObject(wrappedValue: store ?? PatchProjectStore())
        self.showsFreeFireCard = showsFreeFireCard
        self.allowedPackageNames = allowedPackageNames
        self.allowedBundleIdentifier = allowedBundleIdentifier
    }

    private var scopedItems: [PatchLibraryItem] {
        guard let allowedPackageNames else { return store.items }
        return store.items.filter { item in
            // Bundled patches keep their historical obfuscated filenames. Imported
            // patches may use any original filename, so classify them by the game
            // bundle identifier instead of dropping them from the card.
            if allowedPackageNames.contains(item.packageURL.lastPathComponent) {
                return true
            }
            guard let allowedBundleIdentifier,
                  let project = item.project else { return false }
            return project.allBundleIdentifiers.contains(allowedBundleIdentifier)
        }
    }

    private var filteredItems: [PatchLibraryItem] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return scopedItems }
        return scopedItems.filter { item in
            let shownName = item.packageURL.deletingPathExtension().lastPathComponent
            if shownName.localizedCaseInsensitiveContains(query) {
                return true
            }
            guard let project = item.project else { return false }
            return project.name.localizedCaseInsensitiveContains(query)
                || project.allBundleIdentifiers.contains {
                    $0.localizedCaseInsensitiveContains(query)
                }
                || project.directories.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                }
                || project.rules.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                        || $0.replacementFilename.localizedCaseInsensitiveContains(query)
                }
        }
    }

    var body: some View {
        NavigationStack {
            Group {
                if showsFreeFireCard {
                    VStack(spacing: 12) {
                        freeFireCard
                        freeFireMaxCard
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                } else {
                    patchesList
                }
            }
            .navigationTitle(showsFreeFireCard ? language.text("patch.title") : "")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(showsFreeFireCard ? .visible : .hidden, for: .navigationBar)
            .appScreenBackground()
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert(item: $store.alert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .onReceive(NotificationCenter.default.publisher(for: .phxiterPatchDiagnostic)) { notification in
                guard let action = notification.userInfo?["action"] as? String,
                      let name = notification.userInfo?["name"] as? String else { return }
                let timestamp = Self.diagnosticTimestamp()
                diagnosticLogs.append("[\(timestamp)] \(action) \(name)")
                if diagnosticLogs.count > 6 {
                    diagnosticLogs.removeFirst(diagnosticLogs.count - 6)
                }
                currentStatus = action == "Mod injetado" ? "Mod injetado" : "Original restaurado"
            }
        }
    }

    private static func diagnosticTimestamp() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: Date())
    }

    private var patchesList: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(spacing: 0) {
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "chevron.left")
                            .font(.title2.weight(.medium))
                            .foregroundStyle(.primary)
                            .frame(width: 58, height: 58)
                            .background(Color.white, in: Circle())
                    }
                    .buttonStyle(.plain)
                    Spacer()
                    Text("Patches")
                        .font(.system(size: 28, weight: .bold))
                    Spacer()
                    Color.clear.frame(width: 58, height: 58)
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 12)

                diagnosticPanel
                    .padding(.horizontal, 18)
                    .padding(.bottom, 16)

                AppSearchField(
                    text: $searchText,
                    prompt: "Pesquisar patches",
                    clearLabel: language.text("common.clear")
                )
                .padding(.horizontal, 28)
                .padding(.bottom, 18)

                VStack(spacing: 0) {
                    if scopedItems.isEmpty && !store.isBusy {
                        emptyState.padding(24)
                    } else if filteredItems.isEmpty && !store.isBusy {
                        searchEmptyState.padding(24)
                    } else {
                        ForEach(filteredItems) { item in
                            itemRow(item)
                                .padding(.horizontal, 18)
                            if item.id != filteredItems.last?.id {
                                Divider().padding(.leading, 96).padding(.trailing, 28)
                            }
                        }
                    }
                }
                .padding(.vertical, 12)
                .background(Color.white, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                .padding(.horizontal, 18)
            }
            .padding(.bottom, 24)
        }
        .background(Color(red: 0.97, green: 0.98, blue: 1.0).ignoresSafeArea())
    }

    private var freeFireCard: some View {
        NavigationLink {
            PatchProjectsView(
                showsFreeFireCard: false,
                allowedPackageNames: Self.freeFirePackageNames,
                allowedBundleIdentifier: "com.dts.freefireth",
                store: store
            )
        } label: {
            AppCard(padding: 0) {
                HStack(spacing: 14) {
                    Image("FreeFire")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 92, height: 92)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                    VStack(alignment: .leading, spacing: 5) {
                        Text("Free Fire")
                            .font(.headline.weight(.bold))
                            .foregroundStyle(.primary)
                        Text("Abrir arquivos pré-carregados")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text("com.dts.freefireth")
                            .font(.caption.monospaced())
                            .foregroundStyle(AppTheme.accent)
                    }

                    Spacer(minLength: 6)
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.tertiary)
                }
                .padding(14)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Free Fire")
        .accessibilityHint("Abre os arquivos pré-carregados")
    }

    private var freeFireMaxCard: some View {
        NavigationLink {
            PatchProjectsView(
                showsFreeFireCard: false,
                allowedPackageNames: Self.freeFireMaxPackageNames,
                allowedBundleIdentifier: "com.dts.freefiremax",
                store: store
            )
        } label: {
            AppCard(padding: 0) {
                HStack(spacing: 14) {
                    Image("FreeFireMax")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 92, height: 92)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                    VStack(alignment: .leading, spacing: 5) {
                        Text("Free Fire MAX")
                            .font(.headline.weight(.bold))
                            .foregroundStyle(.primary)
                        Text("Abrir arquivos pré-carregados")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text("com.dts.freefiremax")
                            .font(.caption.monospaced())
                            .foregroundStyle(AppTheme.accent)
                    }

                    Spacer(minLength: 6)
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.tertiary)
                }
                .padding(14)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Free Fire MAX")
        .accessibilityHint("Abre uma tela vazia para os arquivos do Free Fire MAX")
    }

    private var diagnosticPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("STATUS")
                .font(.caption.weight(.heavy))
                .foregroundStyle(Color(red: 0.24, green: 0.55, blue: 1.0))

            HStack(spacing: 12) {
                Circle()
                    .fill(Color(red: 0.36, green: 0.62, blue: 1.0))
                    .frame(width: 12, height: 12)
                Text(currentStatus)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
            }

            Text("DIAGNÓSTICO EM TEMPO REAL")
                .font(.caption.weight(.heavy))
                .foregroundStyle(Color(red: 0.24, green: 0.55, blue: 1.0))

            VStack(alignment: .leading, spacing: 6) {
                ForEach(Array(diagnosticLogs.enumerated()), id: \.offset) { _, line in
                    Text(line)
                        .font(.system(size: 13, design: .monospaced))
                        .foregroundStyle(Color(red: 0.18, green: 0.95, blue: 0.58))
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(22)
        .background(Color.black, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    @ViewBuilder
    private func itemRow(_ item: PatchLibraryItem) -> some View {
        if item.isLocked {
            Button { store.requestUnlock(for: item) } label: {
                PatchProjectRow(store: store, item: item, language: language)
            }
            .buttonStyle(.plain)
        } else {
            PatchProjectRow(store: store, item: item, language: language)
        }
    }

    private var emptyState: some View {
        AppEmptyState(
            systemName: "shippingbox.fill",
            title: language.text("patch.empty_title"),
            message: language.text("patch.empty_message")
        )
    }

    private var searchEmptyState: some View {
        AppEmptyState(
            systemName: "magnifyingglass",
            title: language.text("patch.search_empty"),
            message: language.text("patch.search_empty_message")
        )
    }
}

private struct PatchProjectRow: View {
    @ObservedObject var store: PatchProjectStore
    let item: PatchLibraryItem
    let language: AppLanguage
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: item.id)
    }

    private var displayName: String {
        item.packageURL.deletingPathExtension().lastPathComponent
    }

    var body: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                AppRowIcon(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
                Text(displayName)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Spacer()
                if item.summary.isPasswordProtected {
                    Image(systemName: "key.fill")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .accessibilityLabel(language.text("patch.password_protected"))
                }
            }

            if !item.isLocked {
                Toggle(isOn: toggleBinding) {
                    Label(
                        language.text(receipt == nil ? "patch.toggle_off" : "patch.toggle_on"),
                        systemImage: receipt == nil ? "power" : "power.circle.fill"
                    )
                }
                .tint(AppTheme.accent)
                .toggleStyle(GamerToggleStyle())
                .disabled(isWorking)

            }
        }
        .padding(.vertical, 8)
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
    }

    private var toggleBinding: Binding<Bool> {
        Binding(
            get: { receipt != nil },
            set: { enabled in
                guard !isWorking else { return }
                if enabled {
                    showApplyConfirmation = true
                } else if receipt != nil {
                    showRestoreConfirmation = true
                }
            }
        )
    }

    private func apply() {
        guard let project = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let projectToApply = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : project
                _ = try DevicePatchService.apply(project: projectToApply)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    NotificationCenter.default.post(
                        name: .phxiterPatchDiagnostic,
                        object: nil,
                        userInfo: ["action": "Mod injetado", "name": displayName]
                    )
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: error.localizationKey, messageArgument: error.localizationArgument)
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    store.reload()
                    NotificationCenter.default.post(
                        name: .phxiterPatchDiagnostic,
                        object: nil,
                        userInfo: ["action": "Mod desativado", "name": displayName]
                    )
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: error.localizationKey, messageArgument: error.localizationArgument)
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .appScreenBackground()
            .appTint()
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Toggle(isOn: patchToggleBinding) {
                        Label(
                            language.text(receipt == nil ? "patch.toggle_off" : "patch.toggle_on"),
                            systemImage: receipt == nil ? "power" : "power.circle.fill"
                        )
                    }
                    .tint(AppTheme.accent)
                    .disabled(isWorking)

                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .appScreenBackground()
                    .navigationTitle(item?.packageURL.lastPathComponent ?? language.text("patch.title"))

        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
    }

    private var patchToggleBinding: Binding<Bool> {
        Binding(
            get: { receipt != nil },
            set: { isEnabled in
                guard !isWorking else { return }
                if isEnabled {
                    showApplyConfirmation = true
                } else if receipt != nil {
                    showRestoreConfirmation = true
                }
            }
        )
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}



private struct GamerToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack(spacing: 12) {
            configuration.label
                .font(.body)
                .foregroundStyle(.primary)
            Spacer(minLength: 12)
            Button {
                withAnimation(.easeInOut(duration: 0.18)) {
                    configuration.isOn.toggle()
                }
            } label: {
                ZStack {
                    Capsule(style: .continuous)
                        .fill(configuration.isOn ? Color.blue : Color.gray.opacity(0.42))
                        .frame(width: 56, height: 34)
                    Circle()
                        .fill(.white)
                        .frame(width: 28, height: 28)
                        .shadow(color: .black.opacity(0.18), radius: 2, y: 1)
                        .offset(x: configuration.isOn ? 11 : -11)
                }
            }
            .buttonStyle(.plain)
        }
    }
}
