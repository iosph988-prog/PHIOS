#import "vinhtran.hpp"
#import "loading.hxx"
#include <fstream>
#define FMT_HEADER_ONLY
#include "fmt/core.h"
#include <chrono>
#include "hook/hook.h"
extern ImVec4 espv; 
extern ImVec4 espi; 
extern ImVec4 nameColor;
extern ImVec4 distanceColor;
extern bool istelekill;
extern bool isfly;
static void Transform_INTERNAL_SetPosition(void *transform, Vvector3 in) {
    void (*_SetPos)(void *, Vvector3) = (void (*)(void *, Vvector3))getRealOffset(oxo("0x91CA6A8"));
    _SetPos(transform, in);
}
typedef void* DamageInfo2_o;
inline float get_distance(Vector3 a, Vector3 b) {
float dx = a.x - b.x;
 float dy = a.y - b.y;
float dz = a.z - b.z;
 return sqrtf(dx * dx + dy * dy + dz * dz);
}
static ImVec4 colorESPVisible   = ImVec4(0.0f, 1.0f, 0.0f, 1.0f); 
static ImVec4 colorESPInvisible = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); 
bool AimKill = false;
bool SowDamage = true;
bool autochangeweapon = false;
bool POFFNNMOOBM = false;
int GDKLMFLNNGM = 0;
struct Vars_t
{
    int Target = {};
    bool SilentAim = false;
    bool AimKill = false;
    bool AutoWeaponSwitch = false;
    bool tele10 = false;
    bool UpPlayerOne = false;
    bool Enable = {};
    bool AimbotEnable = {};
    bool Aimbot = {};
    float AimFov = {};
    int AimCheck = {};
    int AimType = {};
    int AimWhen = {};
    bool isAimFov = {};
    int AimHitbox = 0; 
    const char* aimHitboxes[3] = {" Cabeça", " Pescoço", " Corpo"};
    const char* dir[4] = { " Automático", " Disparo", " Escopo", " Disparo + Escopo" };
    bool lines = {};
    bool Box = {};
    bool Outline = {};
    bool Name = {};
    bool Health = {};
    bool Distance = {};
    bool fovaimglow = {};
    bool circlepos = {};
    bool skeleton = {};
    bool OOF = {};
    bool counts = {};
    ImVec4 boxColor = ImVec4(1.0f, 0.0f, 0.0f, 0.8f);
    float AimSpeed = 9999.0f; 
    bool VisibleCheck = false; 
    bool IgnoreKnocked = false; 
    int BoxStyle = 0; 
    int HealthPosition = 0; 
    int HealthBarStyle = 0; 
    int LineStyle = 0; 
    int NameStyle = 0; 
    bool forceHighFPS = false;
    bool aimbotVisible = false;
    bool line = false;} Vars;
extern ImVec4 menuColor;
extern bool ShowFOV; 
class game_sdk_t
{
public:
    void init();
    int (*GetHp)(void *player);
    void *(*Curent_Match)();
    void *(*GetLocalPlayer)(void *Game);
    void *(*GetHeadPositions)(void *player);
    Vector3 (*get_position)(void *player);
    void *(*Component_GetTransform)(void *player);
    void *(*get_camera)();
    Vector3 (*WorldToViewpoint)(void*, Vector3, int);
    bool (*get_isVisible)(void *player);
    bool (*get_isLocalTeam)(void *player);
    bool (*get_IsDieing)(void *player);
    int (*get_MaxHP)(void *player);
    Vector3 (*GetForward)(void *player);
    void (*set_aim)(void *player, Quaternion look);
    bool (*get_IsSighting)(void *player);
    bool (*get_IsFiring)(void *player);
    monoString *(*name)(void *player);
    void *(*_GetHeadPositions)(void *);
    void *(*_newHipMods)(void *);
    void *(*_GetLeftAnkleTF)(void *);
    void *(*_GetRightAnkleTF)(void *);
    void *(*_GetLeftToeTF)(void *);
    void *(*_GetRightToeTF)(void *);
    void *(*_getLeftHandTF)(void *);
    void *(*_getRightHandTF)(void *);
    void *(*_getLeftForeArmTF)(void *);
    void *(*_getRightForeArmTF)(void *);
};
game_sdk_t *game_sdk = new game_sdk_t();
void game_sdk_t::init()
{ 
    this->GetHp = (int (*)(void *))getRealOffset(oxo("0x543592C"));
    this->Curent_Match = (void *(*)())getRealOffset(oxo("0x55C4DA4"));
    this->GetLocalPlayer = (void *(*)(void *))getRealOffset(oxo("0x2FFE494"));
    this->GetHeadPositions = (void *(*)(void *))getRealOffset(oxo("0x91CA56C"));
    this->get_position = (Vector3(*)(void *))getRealOffset(oxo("0x91CA56C"));
    this->Component_GetTransform = (void *(*)(void *))getRealOffset(oxo("0x91B82E4"));
    this->get_camera = (void *(*)())getRealOffset(oxo("0x915E9E4"));
    this->WorldToViewpoint = (Vector3(*)(void*, Vector3, int))getRealOffset(oxo("0x915E364"));
    
    this->get_isVisible = (bool (*)(void *))getRealOffset(oxo("0x53C8894"));
    this->get_isLocalTeam = (bool (*)(void *))getRealOffset(oxo("0x53E20C4"));
    this->get_IsDieing = (bool (*)(void *))getRealOffset(oxo("0x53AA18C"));
    this->get_MaxHP = (int (*)(void *))getRealOffset(oxo("0x5435A3C"));
    this->GetForward = (Vector3(*)(void *))getRealOffset(oxo("0x91CAF64"));
    this->set_aim = (void (*)(void *, Quaternion))getRealOffset(oxo("0x53C4534"));
    this->get_IsSighting = (bool (*)(void *))getRealOffset(oxo("0x53B769C"));
    this->get_IsFiring = (bool (*)(void *))getRealOffset(oxo("0x53ACC9C"));
    this->name = (monoString * (*)(void *player)) getRealOffset(oxo("0x53BE8E0"));

    this->_GetHeadPositions = (void *(*)(void *))getRealOffset(oxo("0x54547E0"));
    this->_newHipMods = (void *(*)(void *))getRealOffset(oxo("0x5454990"));
    this->_GetLeftAnkleTF = (void *(*)(void *))getRealOffset(oxo("0x5454DE0"));
    this->_GetRightAnkleTF = (void *(*)(void *))getRealOffset(oxo("0x5454EEC"));
    this->_GetLeftToeTF = (void *(*)(void *))getRealOffset(oxo("0x5454FF8"));
    this->_GetRightToeTF = (void *(*)(void *))getRealOffset(oxo("0x5455104"));
    this->_getLeftHandTF = (void *(*)(void *))getRealOffset(oxo("0x53C3608"));
    this->_getRightHandTF = (void *(*)(void *))getRealOffset(oxo("0x53C370C"));
    this->_getLeftForeArmTF = (void *(*)(void *))getRealOffset(oxo("0x53C3810"));
    this->_getRightForeArmTF = (void *(*)(void *))getRealOffset(oxo("0x53C3914"));
}
namespace Camera$$WorldToScreen {
    ImVec2 Regular(Vector3 pos) {
        auto cam = game_sdk->get_camera();
        if (!cam) return {0,0};

        Vector3 worldPoint = game_sdk->WorldToViewpoint(cam,pos, 2);
        Vector3 location;

        int ScreenWidth = ImGui::GetIO().DisplaySize.x;
        int ScreenHeight = ImGui::GetIO().DisplaySize.y;

        location.x = ScreenWidth * worldPoint.x;
        location.y = ScreenHeight - worldPoint.y * ScreenHeight;
        location.z  = worldPoint.z;

        return {location.x, location.y};
    }

    ImVec2 Checker(Vector3 pos, bool &checker) {
        auto cam = game_sdk->get_camera();
        if (!cam) return {0, 0};
       
        Vector3 worldPoint = game_sdk->WorldToViewpoint(cam,pos, 4);
        Vector3 location;
     
        int ScreenWidth = ImGui::GetIO().DisplaySize.x;
        int ScreenHeight = ImGui::GetIO().DisplaySize.y;
     
        location.x = ScreenWidth * worldPoint.x;
        location.y = ScreenHeight - worldPoint.y * ScreenHeight;
        location.z = worldPoint.z;
     
        checker = location.z > 1;
     
        return {location.x, location.y};
    }
}
Vector3 GetBonePosition(void *player, void *(*transformGetter)(void *)) {
    if (!player || !transformGetter)
        return Vector3();
    void *transform = transformGetter(player);
    return transform ? game_sdk->get_position(game_sdk->Component_GetTransform(transform)) : Vector3();
}
Vector3 GetHitboxPosition(void* player, int hitbox) {
    if (!player) return Vector3::zero();
    switch (hitbox) {
        case 0: return GetBonePosition(player, game_sdk->_GetHeadPositions); 
        case 1: {
            Vector3 headPos = GetBonePosition(player, game_sdk->_GetHeadPositions);
            return headPos == Vector3::zero() ? headPos : Vector3(headPos.x, headPos.y - 0.05f, headPos.z); 
        }
        case 2: {
            Vector3 headPos = GetBonePosition(player, game_sdk->_GetHeadPositions);
            return headPos == Vector3::zero() ? headPos : Vector3(headPos.x, headPos.y - 0.2f, headPos.z); 
        }
        default: return GetBonePosition(player, game_sdk->_GetHeadPositions);
    }
}
Vector3 getPosition(void *player) {
    return game_sdk->get_position(game_sdk->Component_GetTransform(player));
}
static Vector3 GetHeadPosition(void *player) {
    return game_sdk->get_position(game_sdk->GetHeadPositions(player));
}
static Vector3 CameraMain(void *player) {
    return game_sdk->get_position(*(void **)((uint64_t)player + oxo("0x380")));//public Transform MainCameraTransform;
}
Quaternion GetRotationToTheLocation(Vector3 Target, float Height, Vector3 MyEnemy) {
    Vector3 direction = (Target + Vector3(0, Height, 0)) - MyEnemy;
    return Quaternion::LookRotation(direction, Vector3(0, 1, 0));
}
Quaternion GetCurrentRotation(void* player) {
    void* transform = game_sdk->Component_GetTransform(player);
    if (!transform) return Quaternion();
    return Quaternion::LookRotation(game_sdk->GetForward(transform), Vector3(0, 1, 0));
}
#include "Helper/Ext.h"
class tanghinh {
public:
    static Vector3 Transform_GetPosition(void *player) {
       Vector3 out = Vector3::zero();
        void (*_Transform_GetPosition)(void *transform, Vector3 *out) = (void (*)(void *, Vector3 *))getRealOffset(oxo("0x91CA5D0"));//private void get_position_Injected(out Vector3 ret) { }
        _Transform_GetPosition(player, &out);
        return out;
    }

    static void *Player_GetHeadCollider(void *player)
    {
        void *(*_Player_GetHeadCollider)(void *players) = (void *(*)(void *))getRealOffset(oxo("0x53C2630"));//public virtual Collider get_HeadCollider() { }
        return _Player_GetHeadCollider(player);
    }

    static bool Physics_Raycast(Vector3 camLocation, Vector3 headLocation, unsigned int LayerID, void *collider)
    {
        bool (*_Physics_Raycast)(Vector3 camLocation, Vector3 headLocation, unsigned int LayerID, void *collider) = (bool (*)(Vector3, Vector3, unsigned int, void *))getRealOffset(oxo("0x5FE855C"));//public static bool SingleLineCheck(Vector3 startTrace, Vector3 endTrace, uint traceFlag, ref HitObjectInfo hitObjectInfo) { }
        return _Physics_Raycast(camLocation, headLocation, LayerID, collider);
    }

    static bool isVisible(void *enemy) {
        if (enemy != NULL) {
            void *hitObj = NULL;
            auto Camera = Transform_GetPosition(game_sdk->Component_GetTransform(game_sdk->get_camera()));
            auto Target = Transform_GetPosition(game_sdk->Component_GetTransform(Player_GetHeadCollider(enemy)));
            return !Physics_Raycast(Camera, Target, 12, &hitObj);
        }
        return false;
    }
};
void DrawLine(ImDrawList* drawList, ImVec2 start, ImVec2 end, float thickness, bool isDead = false, bool isVisible = false) {
    if (!drawList) return;
ImColor color = 
    isDead              
    ? ImColor(255, 0, 0)          
    : isVisible         
        ? ImColor(colorESPVisible)    
        : ImColor(colorESPInvisible); 
    drawList->AddLine(start, end, color, thickness);
}
void DrawHealthBar(ImDrawList* drawList, ImVec2 start, ImVec2 end, float healthMultiplier, float thickness, bool isDead = false) {
    if (!drawList) return;
    float totalHeight = end.y - start.y;
    float healthHeight = totalHeight * healthMultiplier;
    drawList->AddRectFilled(
        ImVec2(start.x - thickness/2, start.y),
        ImVec2(start.x + thickness/2, end.y),
        ImColor(50, 50, 50, 200)
    );
    if (healthMultiplier > 0) {
        ImColor color = isDead ? ImColor(255, 0, 0) : ImColor(0, 255, 0);
        drawList->AddRectFilled(
            ImVec2(start.x - thickness/2, end.y - healthHeight),
            ImVec2(start.x + thickness/2, end.y),
            color
        );
    }
    if (Vars.Outline) {
        drawList->AddRect(
            ImVec2(start.x - thickness/2 - 1, start.y - 1),
            ImVec2(start.x + thickness/2 + 1, end.y + 1),
            ImColor(0, 255, 0)
        );
    }
}
void DrawSkeleton(void* player, ImDrawList* drawList, float scale_factor) {
    if (!player || !drawList)
        return;
    bool isPlayerVisible = tanghinh::isVisible(player);
    bool isPlayerDead = game_sdk->get_IsDieing(player);
    Vector3 headPos = GetBonePosition(player, game_sdk->_GetHeadPositions);
    Vector3 hipPos = GetBonePosition(player, game_sdk->_newHipMods);
    Vector3 leftAnklePos = GetBonePosition(player, game_sdk->_GetLeftAnkleTF);
    Vector3 rightAnklePos = GetBonePosition(player, game_sdk->_GetRightAnkleTF);
    Vector3 leftToePos = GetBonePosition(player, game_sdk->_GetLeftToeTF);
    Vector3 rightToePos = GetBonePosition(player, game_sdk->_GetRightToeTF);
    Vector3 leftHandPos = GetBonePosition(player, game_sdk->_getLeftHandTF);
    Vector3 rightHandPos = GetBonePosition(player, game_sdk->_getRightHandTF);
    Vector3 leftForeArmPos = GetBonePosition(player, game_sdk->_getLeftForeArmTF);
    Vector3 rightForeArmPos = GetBonePosition(player, game_sdk->_getRightForeArmTF);
    bool visible;
    ImVec2 headScreen = Camera$$WorldToScreen::Checker(headPos, visible);
    if (!visible)
        return;
    ImVec2 hipScreen = Camera$$WorldToScreen::Regular(hipPos);
    ImVec2 leftAnkleScreen = Camera$$WorldToScreen::Regular(leftAnklePos);
    ImVec2 rightAnkleScreen = Camera$$WorldToScreen::Regular(rightAnklePos);
    ImVec2 leftToeScreen = Camera$$WorldToScreen::Regular(leftToePos);
    ImVec2 rightToeScreen = Camera$$WorldToScreen::Regular(rightToePos);
    ImVec2 leftHandScreen = Camera$$WorldToScreen::Regular(leftHandPos);
    ImVec2 rightHandScreen = Camera$$WorldToScreen::Regular(rightHandPos);
    ImVec2 leftForeArmScreen = Camera$$WorldToScreen::Regular(leftForeArmPos);
    ImVec2 rightForeArmScreen = Camera$$WorldToScreen::Regular(rightForeArmPos);
    float thickness = 1.0f;
    ImColor color = 
    isPlayerDead              
    ? ImColor(255, 0, 0)      
    : isPlayerVisible         
        ? ImColor(colorESPVisible)    
        : ImColor(colorESPInvisible); 
    drawList->AddLine(headScreen, hipScreen, color, thickness);
    drawList->AddLine(headScreen, leftForeArmScreen, color, thickness);
    drawList->AddLine(headScreen, rightForeArmScreen, color, thickness);
    drawList->AddLine(leftForeArmScreen, leftHandScreen, color, thickness);
    drawList->AddLine(rightForeArmScreen, rightHandScreen, color, thickness);
    drawList->AddLine(hipScreen, leftAnkleScreen, color, thickness);
    drawList->AddLine(hipScreen, rightAnkleScreen, color, thickness);
    drawList->AddLine(leftAnkleScreen, leftToeScreen, color, thickness);
    drawList->AddLine(rightAnkleScreen, rightToeScreen, color, thickness);
}
bool isFov(Vector3 vec1, Vector3 vec2, int radius) {
    float dx = vec1.x - vec2.x;
    float dy = vec1.y - vec2.y;
    return (dx * dx + dy * dy) <= (radius * radius);
}
void *GetClosestEnemy() {
    try {
        float shortestDistance = 250.0f;
        void *closestEnemy = NULL;
        void *get_MatchGame = game_sdk->Curent_Match();
        if (!get_MatchGame)
            return NULL;
        void *LocalPlayer = game_sdk->GetLocalPlayer(get_MatchGame);
        if (!LocalPlayer || !game_sdk->Component_GetTransform(LocalPlayer))
            return NULL;
        if (!Vars.Aimbot && !Vars.Enable)
            return NULL;
        Dictionary<uint8_t *, void **> *players = *(Dictionary<uint8_t *, void **> **)((long)get_MatchGame + oxo("0x148"));
        if (!players)
            return NULL;
        Vector3 LocalPlayerPos = getPosition(LocalPlayer);
        ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2);
        for (int u = 0; u < players->getSize(); u++) {
            void *Player = players->getValues()[u];
            if (!Player || Player == LocalPlayer || !game_sdk->get_MaxHP(Player) || game_sdk->get_isLocalTeam(Player))
                continue;
            if (Vars.IgnoreKnocked && game_sdk->get_IsDieing(Player))
                continue;
            if (Vars.VisibleCheck && !tanghinh::isVisible(Player))
                continue;
            Vector3 PlayerPos = GetHitboxPosition(Player, Vars.AimHitbox);
            float distance = Vector3::Distance(LocalPlayerPos, PlayerPos);
            if (distance >= 300)
                continue;
            ImVec2 enemyScreenPos = Camera$$WorldToScreen::Regular(PlayerPos);
            bool isValidTarget = isFov(Vector3(enemyScreenPos.x, enemyScreenPos.y, 0), Vector3(center.x, center.y, 0), Vars.AimFov);
            if (isValidTarget && distance < shortestDistance) {
                shortestDistance = distance;
                closestEnemy = Player;
            }
        }
        return closestEnemy;
    } catch (...) {
        return NULL;
    }
}

void NoRecoil(void* instance, Vector3* recoilVec, float a1, float a2) {
    if (!Vars.SilentAim && !Vars.Enable) return;
    recoilVec->x = 0;
    recoilVec->y = 0;
    recoilVec->z = 0;
}
void bitch(void *_this, float a1, float a2) {
    if (!_this && !Vars.Enable) return;

    void* local = game_sdk->GetLocalPlayer(game_sdk->Curent_Match());
    if (!local && !game_sdk->Component_GetTransform(local)) return;

    if (!game_sdk->get_IsFiring(local)) return;

    void* target = GetClosestEnemy();
    if (!target) return;
if (game_sdk->GetHp(target) <= 0) return;
    Vector3 targetPos;

    switch (Vars.Target) {
        case 0:
            targetPos = GetHeadPosition(target);
            break;
        case 1:
            targetPos = GetHeadPosition(target);
            break;
        case 2:
            targetPos = GetHeadPosition(target);
            break;
    }

    Vector3 eye = GetHeadPosition(local); 

    Quaternion aimRot = GetRotationToTheLocation(targetPos, 0, eye);

    if (Vars.SilentAim) {
       
        game_sdk->set_aim(local, aimRot);
    } else if (Vars.Aimbot) {
        
    }
}

void AutoHookSilentFire() {
    static bool isHooked = false;
  void* fireOffset = (void*)getRealOffset(ENCRYPTOFFSET("0x10523717C"));
    void* noRecoilAddr = (void*)getRealOffset(ENCRYPTOFFSET("0x105174020"));

    if (!Vars.SilentAim) return;

    void* match = game_sdk->Curent_Match();
    if (!match) return;

    void* local = game_sdk->GetLocalPlayer(match);
   if (!local || !game_sdk->Component_GetTransform(local)) return;
    bool isFiring = game_sdk->get_IsFiring(local);

    
    if (!isFiring && isHooked) {

   Unhook(fireOffset);
Unhook(noRecoilAddr);
        isHooked = false;
        return;
    }

  
    if (isFiring) {
        void* enemy = GetClosestEnemy();
        if (!enemy || game_sdk->GetHp(enemy) <= 0) return;

        if (!isHooked) {
            void* addr[] = { fireOffset, noRecoilAddr };
            void* func[] = { (void*)bitch, (void*)NoRecoil };
            hook(addr, func, 2);
            isHooked = true;
        }
    }
}

void PullEnemiesToPlayer() {
    if (!Vars.Enable || !Vars.tele10)
        return;

    void *match = game_sdk->Curent_Match();
    if (!match) return;

    void *local = game_sdk->GetLocalPlayer(match);
    if (!local || !game_sdk->Component_GetTransform(local)) return;

    Dictionary<uint8_t *, void **> *players = *(Dictionary<uint8_t *, void **> **)((long)match + 0x148);
    if (!players) return;

    void *localTF = game_sdk->Component_GetTransform(local);
    Vector3 localPos = getPosition(localTF);
    Vector3 forward = game_sdk->GetForward(localTF);

    for (int i = 0; i < players->getSize(); i++) {
        void *enemy = players->getValues()[i];
        if (!enemy || enemy == local) continue;
        if (!game_sdk->Component_GetTransform(enemy)) continue;
        if (!game_sdk->get_MaxHP(enemy)) continue;
        if (game_sdk->get_IsDieing(enemy)) continue;
        if (game_sdk->GetHp(enemy) <= 0) continue;
        if (game_sdk->get_isLocalTeam(enemy)) continue;

        void *enemyTF = game_sdk->Component_GetTransform(enemy);
        Vector3 enemyPos = getPosition(enemyTF);
        float distance = Vector3::Distance(localPos, enemyPos);

        if (distance > 8.0f)
            continue;

        
        Vector3 stableFront = localPos + forward * 1.2f;
        stableFront.y = localPos.y; // 

        Transform_INTERNAL_SetPosition(enemyTF, Vvector3(stableFront.x, stableFront.y, stableFront.z));
    }
}
void UpOneEnemy() {
    if (!Vars.Enable || !Vars.UpPlayerOne)
        return;

    void *match = game_sdk->Curent_Match();
    if (!match) return;

    void *local = game_sdk->GetLocalPlayer(match);
    if (!local || !game_sdk->Component_GetTransform(local)) return;

    Dictionary<uint8_t *, void **> *players = *(Dictionary<uint8_t *, void **> **)((long)match + 0x148);
    if (!players) return;

    for (int i = 0; i < players->getSize(); i++) {
        void *enemy = players->getValues()[i];
        if (!enemy || enemy == local) continue;
        if (!game_sdk->Component_GetTransform(enemy)) continue;
        if (!game_sdk->get_MaxHP(enemy)) continue;
        if (game_sdk->get_IsDieing(enemy)) continue;
        if (game_sdk->GetHp(enemy) <= 0) continue;
        if (game_sdk->get_isLocalTeam(enemy)) continue;

        void *enemyTF = game_sdk->Component_GetTransform(enemy);
        void *localTF = game_sdk->Component_GetTransform(local);
        if (!enemyTF || !localTF) continue;

        Vector3 enemyPos = getPosition(enemyTF);
        Vector3 localPos = getPosition(localTF);
        float distance = Vector3::Distance(localPos, enemyPos);

        float groundY = enemyPos.y;
        float targetY = groundY + 5.7f;

        float step = 0.90f;
        
        if (enemyPos.y < targetY - 0.1f)
            enemyPos.y += step;
       // else if (enemyPos.y > targetY + 0.1f)
       //     enemyPos.y -= step;

        Transform_INTERNAL_SetPosition(enemyTF, Vvector3(enemyPos.x, enemyPos.y, enemyPos.z));
    }
}

void ProcessAimbot() {
    if (!Vars.Aimbot)
        return;
    void *CurrentMatch = game_sdk->Curent_Match();
    if (!CurrentMatch)
        return;
    void *LocalPlayer = game_sdk->GetLocalPlayer(CurrentMatch);
    if (!LocalPlayer || !game_sdk->Component_GetTransform(LocalPlayer))
        return;
    void *closestEnemy = GetClosestEnemy();
    if (!closestEnemy || !game_sdk->Component_GetTransform(closestEnemy))
        return;
    Vector3 EnemyLocation = GetHitboxPosition(closestEnemy, Vars.AimHitbox);
    if (EnemyLocation == Vector3::zero())
        return;
    Vector3 PlayerLocation = CameraMain(LocalPlayer);
    if (PlayerLocation == Vector3::zero())
        return;
    bool IsScopeOn = game_sdk->get_IsSighting(LocalPlayer);
    bool IsFiring = game_sdk->get_IsFiring(LocalPlayer);
    bool shouldAim =
        (Vars.AimWhen == 0) ||                          
        (Vars.AimWhen == 1 && IsFiring) ||              
        (Vars.AimWhen == 2 && IsScopeOn) ||             
        (Vars.AimWhen == 3 && (IsFiring || IsScopeOn)); 
    if (shouldAim && (Vars.aimbotVisible || tanghinh::isVisible(closestEnemy))) {
        if (game_sdk->get_IsDieing(closestEnemy) && Vars.IgnoreKnocked) {
            float shortestDistance = 9999.0f;
            void *newTarget = NULL;
            Dictionary<uint8_t *, void **> *players = *(Dictionary<uint8_t *, void **> **)((long)CurrentMatch + oxo("0x148"));
            if (players) {
                for (int u = 0; u < players->getSize(); u++) {
                    void *Player = players->getValues()[u];
                    if (!Player || Player == LocalPlayer || !game_sdk->get_MaxHP(Player) || game_sdk->get_isLocalTeam(Player) || Player == closestEnemy)
                        continue;
                    if (Vars.IgnoreKnocked && game_sdk->get_IsDieing(Player))
                        continue;
                    if (Vars.VisibleCheck && !tanghinh::isVisible(Player))
                        continue;
                    Vector3 PlayerPos = GetHitboxPosition(Player, Vars.AimHitbox);
                    float distance = Vector3::Distance(PlayerLocation, PlayerPos);
                    if (distance < 300 && distance < shortestDistance) {
                        shortestDistance = distance;
                        newTarget = Player;
                    }
                }
            }
            if (newTarget) {
                EnemyLocation = GetHitboxPosition(newTarget, Vars.AimHitbox);
                closestEnemy = newTarget;
            } else {
                return;
            }
        }
        Quaternion TargetLook = GetRotationToTheLocation(EnemyLocation, 0.05f, PlayerLocation);
        game_sdk->set_aim(LocalPlayer, TargetLook);
    }
   }
void get_players() {
    ImDrawList *draw_list = ImGui::GetBackgroundDrawList();
    int numberOfPlayersAround = 0;
    if (!Vars.Enable)
        return;
    try {
        // AutoHookSilentFire();
        PullEnemiesToPlayer();
        UpOneEnemy();
        if (Vars.Aimbot) {
            ProcessAimbot();
        }
        void *current_Match = game_sdk->Curent_Match();
        if (!current_Match)
            return;
        void *local_player = game_sdk->GetLocalPlayer(current_Match);
        if (!local_player)
            return;
        Dictionary<uint8_t *, void **> *players = *(Dictionary<uint8_t *, void **> **)((long)current_Match + 0x148);
        if (!players)
            return;
        void *camera = game_sdk->get_camera();
        if (!camera)
            return;
        for (int u = 0; u < players->getSize(); u++) {
            void *closestEnemy = players->getValues()[u];
            if (!closestEnemy || 
                !game_sdk->Component_GetTransform(closestEnemy) || 
                closestEnemy == local_player || 
                !game_sdk->get_MaxHP(closestEnemy) || 
                game_sdk->get_isLocalTeam(closestEnemy)) {
                continue;
            }
            numberOfPlayersAround++;
            Vector3 pos = getPosition(closestEnemy);
            Vector3 pos2 = getPosition(local_player);
            float distance = Vector3::Distance(pos, pos2);
            if (distance > 200.0f)
                continue;
            bool isEnemyDead = game_sdk->get_IsDieing(closestEnemy);
            bool isEnemyVisible = tanghinh::isVisible(closestEnemy);
            bool w2sc;
            ImVec2 top_pos = Camera$$WorldToScreen::Regular(pos + Vector3(0, 1.6, 0));
            ImVec2 bot_pos = Camera$$WorldToScreen::Regular(pos);
            ImVec2 pos_3 = Camera$$WorldToScreen::Checker(pos, w2sc);
            auto pmtXtop = top_pos.x;
            auto pmtXbottom = bot_pos.x;
            if (top_pos.x > bot_pos.x) {
                pmtXtop = bot_pos.x;
                pmtXbottom = top_pos.x;
            }
            Camera$$WorldToScreen::Checker(pos + Vector3(0, 0.75f, 0), w2sc);
            float calculatedPosition = fabs((top_pos.y - bot_pos.y) * (0.0092f / 0.019f) / 2);
            ImRect rect(
                ImVec2(pmtXtop - calculatedPosition, top_pos.y),
                ImVec2(pmtXbottom + calculatedPosition, bot_pos.y));
            const auto &viewpos = game_sdk->get_position(game_sdk->Component_GetTransform(game_sdk->get_camera()));
           if (w2sc) {
            float scale_factor = 1.0f;
if (Vars.lines) {
    Vector3 headPos = GetHitboxPosition(closestEnemy, 0); 
    ImVec2 headScreen = Camera$$WorldToScreen::Regular(headPos);
    float line_thickness = 1.0f * scale_factor;
    if (Vars.LineStyle == 0) {
        DrawLine(
            draw_list,
            ImVec2(ImGui::GetIO().DisplaySize.x / 2, 0), 
            headScreen,
            line_thickness,
            isEnemyDead,
            isEnemyVisible);
    } else if (Vars.LineStyle == 1) {
        DrawLine(
            draw_list,
            ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y), 
            headScreen,
            line_thickness,
            isEnemyDead,
            isEnemyVisible);
    }
}
if (Vars.Box) {
    float box_thickness = 1.0f * scale_factor;
    if (Vars.BoxStyle == 0) {
        DrawLine(draw_list, rect.Min, ImVec2(rect.Max.x, rect.Min.y), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, ImVec2(rect.Max.x, rect.Min.y), rect.Max, box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, rect.Max, ImVec2(rect.Min.x, rect.Max.y), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, ImVec2(rect.Min.x, rect.Max.y), rect.Min, box_thickness, isEnemyDead, isEnemyVisible);
        if (Vars.Outline) {
            float outline_thickness = 1.0f * scale_factor;
            draw_list->AddRect(rect.Min - ImVec2(outline_thickness, outline_thickness),
                rect.Max + ImVec2(outline_thickness, outline_thickness),
                ImColor(0, 0, 0),
                0.0f,
                0,
                outline_thickness);
        }
    } else if (Vars.BoxStyle == 1) {
        float cornerLengthX = (rect.Max.x - rect.Min.x) * 0.25f;
        float cornerLengthY = (rect.Max.y - rect.Min.y) * 0.25f;
        DrawLine(draw_list, rect.Min, ImVec2(rect.Min.x + cornerLengthX, rect.Min.y), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, rect.Min, ImVec2(rect.Min.x, rect.Min.y + cornerLengthY), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, ImVec2(rect.Max.x, rect.Min.y), ImVec2(rect.Max.x - cornerLengthX, rect.Min.y), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, ImVec2(rect.Max.x, rect.Min.y), ImVec2(rect.Max.x, rect.Min.y + cornerLengthY), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, ImVec2(rect.Min.x, rect.Max.y), ImVec2(rect.Min.x + cornerLengthX, rect.Max.y), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, ImVec2(rect.Min.x, rect.Max.y), ImVec2(rect.Min.x, rect.Max.y - cornerLengthY), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, rect.Max, ImVec2(rect.Max.x - cornerLengthX, rect.Max.y), box_thickness, isEnemyDead, isEnemyVisible);
        DrawLine(draw_list, rect.Max, ImVec2(rect.Max.x, rect.Max.y - cornerLengthY), box_thickness, isEnemyDead, isEnemyVisible);
    }
}
    if (Vars.skeleton) {
        DrawSkeleton(closestEnemy, draw_list, scale_factor); 
    }
if (Vars.Health) {
    auto health = game_sdk->GetHp(closestEnemy);
    auto maxhealth = game_sdk->get_MaxHP(closestEnemy);
    float health_multiplier = ImClamp((float)health / (float)maxhealth, 0.0f, 1.0f);
    const float bar_width = 3.0f;
    float bar_height = rect.Max.y - rect.Min.y;
    float bar_y = rect.Min.y;
    float bar_x = (Vars.HealthPosition == 0)
        ? rect.Min.x - (bar_width + 4.0f)  
        : rect.Max.x + 4.0f;               
    ImVec2 bar_start = ImVec2(bar_x, bar_y);
    ImVec2 bar_end   = ImVec2(bar_x + bar_width, bar_y + bar_height);
    ImU32 border_color = IM_COL32(0, 0, 0, 255);       
    ImU32 health_color = IM_COL32(0, 255, 0, 255);     
    float filled_height = bar_height * health_multiplier;
    ImVec2 filled_start = ImVec2(bar_x, bar_y + (bar_height - filled_height));
    ImVec2 filled_end   = ImVec2(bar_x + bar_width, bar_y + bar_height);
    draw_list->AddRectFilled(filled_start, filled_end, health_color);
    draw_list->AddRect(bar_start, bar_end, border_color, 0.0f, 0, 0.1f);
}
if (Vars.Name) {
    auto pname = game_sdk->name(closestEnemy);
    std::string names = "null";
    if (pname)
        names = pname->toCPPString();
    std::transform(names.begin(), names.end(), names.begin(), ::tolower);
    std::string name = names;
    ImVec2 text_size = verdana_smol->CalcTextSizeA(8 * scale_factor, FLT_MAX, 0, name.c_str());
    ImVec2 name_pos = {
        rect.Min.x + (rect.GetWidth() / 2) - text_size.x / 2,
        rect.Min.y - 2 - text_size.y
    };
    ImColor nameColor = isEnemyVisible
        ? ImColor(colorESPVisible)    
        : ImColor(colorESPInvisible); 
    if (Vars.NameStyle == 0) {
        ImVec2 bg_min = name_pos - ImVec2(1, 1);
        ImVec2 bg_max = name_pos + text_size + ImVec2(1, 1);
        draw_list->AddRectFilled(bg_min, bg_max, ImColor(0, 0, 0, 100), 0.0f);
        AddText(verdana_smol, 8 * scale_factor, false, Vars.Outline, name_pos, nameColor, name);
    } else if (Vars.NameStyle == 1) {
        AddText(verdana_smol, 8 * scale_factor, false, Vars.Outline, name_pos, nameColor, name);
    }
}
    if (Vars.Distance) {
        std::string distancestr = fmt::format(oxorany("{}M"), static_cast<int>(distance));
        ImVec2 distance_pos = {
            rect.Max.x + 4,
            rect.Min.y
        };
        AddText(pixel_smol, 8 * scale_factor, false, true, distance_pos, ImColor(255, 255, 255), distancestr.c_str());
    }
}
            if (Vars.OOF) {
                if ((pos_3.x < 0 || pos_3.x > disp.width) || (pos_3.y < 0 || pos_3.y > disp.height) || !w2sc) {
                    constexpr int maxpixels = 150;
                    int pixels = maxpixels;
                    if (w2sc) {
                        if (pos_3.x < 0)
                            pixels = clamp((int)-pos_3.x, 0, (int)maxpixels);
                        if (pos_3.y < 0)
                            pixels = clamp((int)-pos_3.y, 0, (int)maxpixels);
                        if (pos_3.x > disp.width)
                            pixels = clamp((int)pos_3.x - (int)disp.width, 0, (int)maxpixels);
                        if (pos_3.y > disp.height)
                            pixels = clamp((int)pos_3.y - (int)disp.height, 0, (int)maxpixels);
                    }
                    float opacity = (float)pixels / (float)maxpixels;
                    float size = 3.5f;
                    Vector3 viewdir = game_sdk->GetForward(game_sdk->Component_GetTransform(game_sdk->get_camera()));
                    Vector3 targetdir = Vector3::Normalized(pos - viewpos);
                    float viewangle = atan2(viewdir.z, viewdir.x) * Rad2Deg;
                    float targetangle = atan2(targetdir.z, targetdir.x) * Rad2Deg;
                    if (viewangle < 0)
                        viewangle += 360;
                    if (targetangle < 0)
                        targetangle += 360;
                    float angle = targetangle - viewangle;
                    while (angle < 0)
                        angle += 360;
                    while (angle > 360)
                        angle -= 360;
                    angle = 360 - angle;
                    angle -= 90;
                    OtFovV1(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2, 90 + distance * 2,
                            angle - size,
                            angle + size,
                            ImColor(1.f, 1.f, 1.f, 1.f * opacity), 1);
                }
            }
        }
        if (Vars.counts) {
            ImDrawList *draw_list = ImGui::GetBackgroundDrawList();
            static ImVec2 prevTextPos = {0, 0};
            static ImVec2 prevTextSize = {0, 0};
            ImVec2 numberPosition(ImGui::GetIO().DisplaySize.x / 2.0f, 12);
            std::string countText = std::to_string(numberOfPlayersAround);
            ImVec2 textSize = pixel_big->CalcTextSizeA(40.0f, FLT_MAX, 0, countText.c_str());
            ImVec2 textPos = ImVec2(
                numberPosition.x - textSize.x / 2.0f,
                numberPosition.y
            );
            if (prevTextSize.x > 0 && prevTextSize.y > 0) {
                draw_list->AddRectFilled(prevTextPos - ImVec2(5, 5), prevTextPos + prevTextSize + ImVec2(5, 5), ImColor(0, 0, 0, 0));
            }
            draw_list->AddText(pixel_big, 40.0f, textPos + ImVec2(1, 1), ImColor(0, 0, 0, 255), countText.c_str());
            draw_list->AddText(pixel_big, 40.0f, textPos + ImVec2(-1, -1), ImColor(0, 0, 0, 255), countText.c_str());
            draw_list->AddText(pixel_big, 40.0f, textPos + ImVec2(1, -1), ImColor(0, 0, 0, 255), countText.c_str());
            draw_list->AddText(pixel_big, 40.0f, textPos + ImVec2(-1, 1), ImColor(0, 0, 0, 255), countText.c_str());
            draw_list->AddText(pixel_big, 40.0f, textPos, ImColor(255, 255, 0, 255), countText.c_str());
            prevTextPos = textPos;
            prevTextSize = textSize;
        }
    } catch (...) {
        return;
    }
}
void aimbot() {
    ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
    if (!draw_list) return;
    if (Vars.line) {
        void* target = GetClosestEnemy();
        if (target) {
            Vector3 targetPos = GetHitboxPosition(target, Vars.AimHitbox);
            ImVec2 screenPos = Camera$$WorldToScreen::Regular(targetPos);
            ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2);
            draw_list->AddLine(center, screenPos, tanghinh::isVisible(target) ? ImColor(0, 255, 0) : ImColor(255, 0, 0), 1.5f);
        }
    }
    if (Vars.isAimFov && Vars.AimFov > 0.0f) {
        ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2);
        draw_list->AddCircle(center, Vars.AimFov, ImGui::ColorConvertFloat4ToU32(menuColor), 100, 2.0f);
    }
    if (!Vars.Aimbot)
        return;
    void* Match = game_sdk->Curent_Match();
    if (!Match)
        return;
    void* LocalPlayer = game_sdk->GetLocalPlayer(Match);
    if (!LocalPlayer || !game_sdk->Component_GetTransform(LocalPlayer))
        return;
    void* playertarget = GetClosestEnemy();
    if (!playertarget)
        return;
    ImVec2 EnemyLocation = Camera$$WorldToScreen::Regular(GetHitboxPosition(playertarget, Vars.AimHitbox));
    ImColor aimbotColor = ImColor(255, 255, 255);
    ProcessAimbot();
}
