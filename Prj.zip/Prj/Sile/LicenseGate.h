#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LicenseGate : NSObject
+ (void)presentForWindow:(UIWindow *)window success:(dispatch_block_t)success;
@end

NS_ASSUME_NONNULL_END
